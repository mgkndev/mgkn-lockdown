print("[mgkn] main.lua loading...\n")

-- ==========================================
-- SHARED: FIND LOCAL PLAYER
-- ==========================================
local function GetMyPlayer()
    local PC = FindFirstOf("PC_C")
    if not PC or not PC:IsValid() then return nil, "PC not found" end
    local Player = PC["Mec Ref"]
    if not Player or not Player:IsValid() then return nil, "Mec Ref not found" end
    return Player, nil
end

local GUID_VALUE = "Value_8_5511228644AD6F4D6D0589BD4438C32F"
local GUID_TIME  = "Time_15_AFBBFC834F820A0E18A707A477B6D3FE"

-- ==========================================
-- ITEM MAP (fixed asset paths -> no class scanning)
-- ==========================================
local ItemMap = {
    ["RIFLE"]     = "/Game/Items/Guns/Rifle/DA_Rifle.DA_Rifle",
    ["PISTOL"]    = "/Game/Items/Guns/Pistol/DA_Pistol.DA_Pistol",
    ["SMG"]       = "/Game/Items/Guns/SMG/DA_SMG.DA_SMG",
    ["SHOTGUN"]   = "/Game/Items/Guns/Shotgun/DA_Shotgun.DA_Shotgun",
    ["REVOLVER"]  = "/Game/Items/Guns/Revolver/DA_Revolver.DA_Revolver",
    ["SHORTY"]    = "/Game/Items/Guns/Shorty/DA_Shorty.DA_Shorty",
    ["GRENADE"]   = "/Game/Items/Grenade/Item/DA_Grenade.DA_Grenade",
    ["C4"]        = "/Game/Items/Melee/C4/DA_C4.DA_C4",
    ["DETONATOR"] = "/Game/Items/Special/Detonator/DA_Detonator.DA_Detonator",
    ["KNIFE"]     = "/Game/Items/Melee/Knife/DA_Knife.DA_Knife",
    ["FISH"]      = "/Game/Items/Melee/Fish/DA_Fish.DA_Fish",
    ["BATTERY"]   = "/Game/Items/Melee/Battery/DA_Battery.DA_Battery",
    ["CARD"]      = "/Game/Items/Melee/AccessCard/DA_AccessCard.DA_AccessCard",
    ["FUSE"]      = "/Game/Items/Melee/Fuze/DA_Fuse.DA_Fuse",
    ["SCREW"]     = "/Game/Items/Melee/ScrewDriver/DA_ScrewDriver.DA_ScrewDriver",
    ["REZ"]       = "/Game/Items/Melee/Rez/DA_Rez.DA_Rez",
    ["VENT"]      = "/Game/Items/Melee/VentFilter/DA_VentFilter.DA_VentFilter",
    ["DISK"]      = "/Game/Items/Melee/HardDrive/DA_HardDrive.DA_HardDrive",
    ["CONTAINER"] = "/Game/Items/Melee/SampleContainer/DA_Container.DA_Container",
    ["SAMPLE"]    = "/Game/Items/Melee/ProcessedSample/DA_Sample.DA_Sample",
    ["COOKIE"]    = "/Game/Items/FieldItems/Cookie/DA_Cookie.DA_Cookie",
    ["TAPE"]      = "/Game/Items/FieldItems/TapeRoll/DA_TapeRoll.DA_TapeRoll",
}

-- Fetches the asset object directly by path, does not scan the whole class
local function GetItemAsset(itemName)
    local path = ItemMap[string.upper(tostring(itemName))]
    if not path then return nil, "Unknown item: " .. tostring(itemName) end
    local asset = StaticFindObject(path) or FindObject(nil, path, 0, 0)
    if asset and asset:IsValid() then return asset, nil end
    return nil, "Asset not found (may not be loaded yet): " .. tostring(itemName)
end

-- ==========================================
-- REAL ITEM GIVING (via server-side RPC, calling the Blueprint function directly)
-- ==========================================
local function GiveItem(itemName, v1, v2)
    local Player, err = GetMyPlayer()
    if not Player then print("[Item] ERROR: " .. err .. "\n") return end

    local asset, aerr = GetItemAsset(itemName)
    if not asset then print("[Item] ERROR: " .. aerr .. "\n") return end

    local itemState = {
        [GUID_VALUE] = math.floor(v1 or 0),
        [GUID_TIME]  = math.floor(v2 or 0)
    }
    local rawAim = Player["Interaction Aim"]
    local aim = {
        X = rawAim and rawAim.X or 0.0,
        Y = rawAim and rawAim.Y or 0.0,
        Z = rawAim and rawAim.Z or 0.0
    }

    local ok, e = pcall(function()
        Player["Set Hand Item"](Player, asset, itemState, false, aim, false, true, false)
        if Player["Net Take Item"] then
            Player["Net Take Item"](Player, asset, itemState, aim)
        end
        if Player["OnRep_Net Hand ItemNew"] then
            Player["OnRep_Net Hand ItemNew"](Player)
        end
    end)

    if ok then
        print("[Item] " .. itemName .. " given (v1=" .. tostring(v1 or 0) .. ", v2=" .. tostring(v2 or 0) .. ").\n")
    else
        print("[Item] Error: " .. tostring(e) .. "\n")
    end
end

-- ==========================================
-- HEAL (two modes)
-- 1) HealFixed: sets to 99 directly (regen tops it up to 100), Z key
-- 2) HealStep: adds HEAL_STEP each press, X key
-- ==========================================
local HEAL_STEP = 20

local function HealFixed()
    local Player, err = GetMyPlayer()
    if not Player then print("[Heal] ERROR: " .. err .. "\n") return end

    local ok, e = pcall(function()
        Player.Health = 99
        Player.Stamina = 0.99
    end)

    if ok then
        print("[Heal] Health/Stamina set to 99 / 0.99.\n")
    else
        print("[Heal] Error: " .. tostring(e) .. "\n")
    end
end

local function HealStep()
    local Player, err = GetMyPlayer()
    if not Player then print("[Heal] ERROR: " .. err .. "\n") return end

    local ok, e = pcall(function()
        local currentHealth = tonumber(Player.Health) or 0
        local newHealth = math.min(currentHealth + HEAL_STEP, 100)
        Player.Health = newHealth
        Player.Stamina = newHealth / 100
    end)

    if ok then
        print(string.format("[Heal] +%d health added.\n", HEAL_STEP))
    else
        print("[Heal] Error: " .. tostring(e) .. "\n")
    end
end

-- ==========================================
-- HEAL LOOP (toggle with Ctrl+H, full heal every 100 ms)
-- ==========================================
local healLoopActive = false

local function HealLoopTick()
    local Player, err = GetMyPlayer()
    if not Player then return end
    pcall(function()
        Player.Health = 100
        Player.Stamina = 1
    end)
end

local function ToggleHealLoop()
    healLoopActive = not healLoopActive

    if healLoopActive then
        print("[HealLoop] Started. (Health/Stamina 100/1 every 100 ms)\n")
        LoopAsync(100, function()
            if not healLoopActive then
                return true
            end
            HealLoopTick()
            return false
        end)
    else
        print("[HealLoop] Stopped.\n")
    end
end

-- ==========================================
-- AMMO
-- ==========================================
local function Ammo(params)
    local amount = tonumber(params and params[1]) or 1
    local Player, err = GetMyPlayer()
    if not Player then print("[Ammo] ERROR: " .. err .. "\n") return end
    local ok, e = pcall(function()
        local state = Player["Hand State"]
        if state and state[GUID_VALUE] then
            state[GUID_VALUE] = state[GUID_VALUE] + amount
            if Player["OnRep_Net Hand ItemNew"] then
                Player["OnRep_Net Hand ItemNew"](Player)
            end
            print("[Ammo] +" .. amount .. " added.\n")
        else
            print("[Ammo] No suitable item in hand.\n")
        end
    end)
    if not ok then
        print("[Ammo] Error: " .. tostring(e) .. "\n")
    end
end

-- ==========================================
-- COMMAND REGISTRATION
-- ==========================================
RegisterConsoleCommandHandler("heal", function(_, params) HealFixed() return true end)
RegisterConsoleCommandHandler("healstep", function(_, params) HealStep() return true end)
RegisterConsoleCommandHandler("ammo", function(_, params) Ammo(params) return true end)

-- Generic: give <NAME> [v1] [v2]
RegisterConsoleCommandHandler("give", function(_, params)
    if not params or not params[1] then
        print("[Give] Usage: give <NAME> [v1] [v2]\n")
        return true
    end
    GiveItem(params[1], tonumber(params[2]) or 0, tonumber(params[3]) or 0)
    return true
end)

-- Detonator
RegisterConsoleCommandHandler("det", function() GiveItem("DETONATOR", 0, 0) return true end)
-- Access Card
RegisterConsoleCommandHandler("ac",  function() GiveItem("CARD", 1, 0) return true end)
-- Battery
RegisterConsoleCommandHandler("bat", function() GiveItem("BATTERY", 100, 0) return true end)

-- Container loop
local cont_map = { e=0, g=1, y=2, b=3, w=4, r=5 }
for key, val in pairs(cont_map) do
    RegisterConsoleCommandHandler("c"..key, function() GiveItem("CONTAINER", val, 0) return true end)
end

-- ==========================================
-- WEAPONS AND OTHER ITEMS (variant supported: e.g. "rif 2")
-- format: { ItemMap_key, amount(v1), default variant(v2) }
-- ==========================================
local item_presets = {
    rif   = {"RIFLE", 20, 0},
    smg   = {"SMG", 30, 0},
    sg    = {"SHOTGUN", 10, 0},
    ps    = {"PISTOL", 12, 0},
    rv    = {"REVOLVER", 6, 0},
    sh    = {"SHORTY", 4, 0},
    knife = {"KNIFE", 0, 0},

    rez   = {"REZ", 100, 0},
    ck    = {"COOKIE", 0, 0},
    c4    = {"C4", 0, 0},
    fuse  = {"FUSE", 0, 0},
    screw = {"SCREW", 0, 0},
    vent  = {"VENT", 100, 0},
    disk  = {"DISK", 0, 0},
    tape  = {"TAPE", 0, 0},

    salmon = {"FISH", 1, 0},
    tuna   = {"FISH", 2, 0},
    cod    = {"FISH", 3, 0},
    shrimp = {"FISH", 4, 0},
}

for cmd, v in pairs(item_presets) do
    RegisterConsoleCommandHandler(cmd, function(_, params)
        local variant = (params and params[1]) and tonumber(params[1]) or v[3]
        GiveItem(v[1], v[2], variant)
        return true
    end)
end

-- DEBUG
RegisterConsoleCommandHandler("debug", function()
    local Player, err = GetMyPlayer()
    if not Player then print("[Debug] ERROR: " .. err .. "\n") return true end
    print("[Debug] Your character: " .. Player:GetFullName() .. "\n")
    return true
end)

RegisterKeyBind(Key.Z, function() HealFixed() end)
RegisterKeyBind(Key.X, function() HealStep() end)
RegisterKeyBind(Key.H, {ModifierKey.CONTROL}, function() ToggleHealLoop() end)

print("[mgkn] heal + ammo + real item giving loaded. Keybinds: Z -> Heal(99), X -> Heal(+20), Ctrl+H -> toggle HealLoop (100ms, full heal)\n")
